
1) Before following git steps go to project explorer(eclipse/sts) -> right click -> show in local terminal -> terminal(git bash)
2) follow git steps document.
3) if error comes for any file right click on file -> replace with -> Head revision
4) Then continue with git steps again.
5) Finally to create PR(pull request) Login to bitbucket.
6) go to create pull request at left hand side
7) select source(girik) and destination(integration) -> click on continue (before continue you can check difference by clicking on diff tab)
8) Add description & reviewers --> click on create. Pull request will get created.

==========================================================================================================================
1) if we created new branch & its not reflecting in eclipse then checkout integration(main) branch, first take a pull and
then try to switch new branch.

==========================================================================================================================
If we changed system login & password after expiration & facing authentication error, then before using git commands need to follow below steps.
1) login to web(GitHub,bitbucket) url with updated credentials.