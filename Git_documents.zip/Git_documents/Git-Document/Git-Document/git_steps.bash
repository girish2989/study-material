gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git status
On branch feature/gkulk
Your branch is up to date with 'origin/integration'.

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
        modified:   pom.xml
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/project/ProjectTrustRepository.java
        modified:   src/main/java/com/mvwc/inventorymgmt/common/constants/Constants.java
        modified:   src/main/java/com/mvwc/inventorymgmt/common/exception/ErrorDictionary.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/ColumnValidation.java
        modified:   src/main/resources/application.properties
        modified:   target/classes/application.properties
        modified:   target/test-classes/application.properties

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        .classpath
        .factorypath
        .settings/
        nullnullfilename.csv
        src/main/java/com/mvwc/inventorymgmt/dgsun/
        src/main/resources/data.sql
        target/classes/CASSECURE.TAB
        target/classes/ESAPI.properties
        target/classes/META-INF/
        target/classes/com/
        target/classes/data.sql
        target/classes/data/
        target/classes/truststore.jks
        target/classes/validation.properties
        target/maven-status/
        target/surefire-reports/
        target/test-classes/data.sql
        target/test-classes/file-upload.csv
        target/test-classes/integration/
        target/test-classes/load_trust_inventory_details.csv
        target/test-classes/test/

no changes added to commit (use "git add" and/or "git commit -a")

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git add src/main/java/com/mvwc/inventorymgmt/client/database/project/ProjectTrustRepository.java src/main/java/com/mvwc/inventorymgmt/common/constants/Constants.java
 src/main/java/com/mvwc/inventorymgmt/common/exception/ErrorDictionary.java src/main/java/com/mvwc/inventorymgmt/uv/sys/init/ColumnValidation.java src/main/java/com/mv
wc/inventorymgmt/dgsun/* 
warning: LF will be replaced by CRLF in src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNMarshaConfigService.java.
The file will have its original line endings in your working directory

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git commit -m "dgsun system initialization"
[feature/gkulk ca67c376] dgsun system initialization
 Committer: Kulkarni <Girish.Kulkarni@vacationclub.com>
Your name and email address were configured automatically based
on your username and hostname. Please check that they are accurate.
You can suppress this message by setting them explicitly:

    git config --global user.name "Your Name"
    git config --global user.email you@example.com

After doing this, you may fix the identity used for this commit with:

    git commit --amend --reset-author

 13 files changed, 1591 insertions(+), 1 deletion(-)
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNData.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNFilesUploadResponseWithStatus.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNInitUtility.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNIntializationController.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNIntialzationService.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNMarshaConfigData.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNMarshaConfigService.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DGSUNService.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/dgsun/sys/init/DgsunAllFilesResponse.java

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git checkout integration
Switched to a new branch 'integration'
M       pom.xml
M       target/test-classes/application.properties
Your branch is ahead of 'origin/integration' by 1 commit.
  (use "git push" to publish your local commits)

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git checkout integration
Switched to branch 'integration'
M       pom.xml
M       src/main/resources/application.properties
M       target/classes/application.properties
M       target/test-classes/application.properties
Your branch is up to date with 'origin/integration'.

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git pull
fatal: Invalid credentials
error: unable to read askpass response from 'C:/Program Files/Git/mingw64/bin/git-askpass.exe'
Password for 'https://Durgamata@89@bitbucket.iilg.com':

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git checkout feature/gkulk
Switched to branch 'feature/gkulk'
M       pom.xml
M       src/main/resources/application.properties        
M       target/classes/application.properties
M       target/test-classes/application.properties       
Your branch is ahead of 'origin/integration' by 1 commit.
  (use "git push" to publish your local commits)

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git checkout integration
Switched to branch 'integration'
M       pom.xml
M       src/main/resources/application.properties 
M       target/classes/application.properties     
M       target/test-classes/application.properties
Your branch is up to date with 'origin/integration'.

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git pull
remote: Enumerating objects: 2060, done.
remote: Counting objects: 100% (2060/2060), done.
remote: Compressing objects: 100% (1106/1106), done.
remote: Total 2060 (delta 754), reused 908 (delta 354)
Receiving objects: 100% (2060/2060), 369.78 KiB | 1.68 MiB/s, done.
Resolving deltas: 100% (754/754), completed with 54 local objects.
From https://bitbucket.iilg.com/scm/mvwcas/mvw-cas-inventory-movement-engine-sapi-v1
   3b0dae7b..64117b31  integration        -> origin/integration
 * [new branch]        feature/IBM_MQ_Critical_section -> origin/feature/IBM_MQ_Critical_section
   b03e448b..c6b1b8bc  feature/critical-section -> origin/feature/critical-section
   49768a8e..d05018fa  feature/integration_Retry_Auto -> origin/feature/integration_Retry_Auto
   3a9ccd22..5ddf8463  feature/m          -> origin/feature/m
 * [new branch]        feature/rojalini   -> origin/feature/rojalini
   78f90c2f..b537a9ac  feature/rsahoo     -> origin/feature/rsahoo
   43276a7a..33bc4b45  feature/sv         -> origin/feature/sv
   4685b922..705e5163  feature/transaction_status -> origin/feature/transaction_status
   ad263f44..24febe29  feature/umash154   -> origin/feature/umash154
 * [new branch]        integration-backup -> origin/integration-backup
 * [new tag]           1.0.0_20220510_0724 -> 1.0.0_20220510_0724
 * [new tag]           1.0.0_20220511_0647 -> 1.0.0_20220511_0647
 * [new tag]           1.0.0_20220512_0735 -> 1.0.0_20220512_0735
 * [new tag]           1.0.0_20220517_0619 -> 1.0.0_20220517_0619
 * [new tag]           1.0.0_20220518_0201 -> 1.0.0_20220518_0201
 * [new tag]           1.0.0_20220518_0750 -> 1.0.0_20220518_0750
 * [new tag]           1.0.0_20220518_0928 -> 1.0.0_20220518_0928
 * [new tag]           1.0.0_20220518_1234 -> 1.0.0_20220518_1234
 * [new tag]           1.0.0_20220519_0845 -> 1.0.0_20220519_0845
 * [new tag]           1.0.0_20220520_0317 -> 1.0.0_20220520_0317
 * [new tag]           1.0.0_20220520_0719 -> 1.0.0_20220520_0719
 * [new tag]           1.0.0_20220523_0637 -> 1.0.0_20220523_0637
 * [new tag]           1.0.0_20220524_0711 -> 1.0.0_20220524_0711
        src/main/resources/application.properties
Please commit your changes or stash them before you merge.
Aborting
Updating 3b0dae7b..8d2d1fad

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git checkout feature/gkulk
Switched to branch 'feature/gkulk'
M       pom.xml
M       src/main/resources/application.properties
M       target/classes/application.properties
M       target/test-classes/application.properties
Your branch and 'origin/integration' have diverged,
and have 1 and 178 different commits each, respectively.
  (use "git pull" to merge the remote branch into yours)

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git checkout integration
Switched to branch 'integration'
M       target/classes/application.properties
M       target/test-classes/application.properties
Your branch is behind 'origin/integration' by 178 commits, and can be fast-forwarded.
  (use "git pull" to update your local branch)

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git pull
Updating files: 100% (166/166), done.
Updating 3b0dae7b..8d2d1fad
Fast-forward
 pom.xml                                            |   2 +-
 .../mvwc/inventorymgmt/algorithm/AutoSubDto.java   |   2 +
 .../algorithm/MarshaBookingParamsDto.java          |  19 +
 .../algorithm/MatchingRuleService.java             | 172 +++----        
 .../algorithm/PointsAlgoServiceImpl.java           |  15 -
 .../inventorymgmt/algorithm/ProjectThresholds.java |  18 +
 .../algorithm/WeeksAlgoServiceImpl.java            | 348 ++++++++++-----
 .../database/file/progress/SourceElection.java     |   4 +-
 .../file/progress/SourceElectiontRepository.java   |   5 +-
 .../inventory/type/EPeatRecordDaoImpl.java         | 123 ++++--
 .../database/inventory/type}/EmailGroup.java       |   4 +-
 .../inventory/type}/EmailGroupRepository.java      |   2 +-
 .../client/database/inventory/type/PEATAction.java |  10 +-
 .../inventory/type/PEATActionRepository.java       |   9 +
 .../inventory/type/PEATActionSpecification.java    |  59 ++-
 .../database/inventory/type/PEATRequest.java       |   6 +-
 .../client/database/res/config/ResConfig.java      |   4 +
 .../inventorymgmt/common/constants/Constants.java  |   2 +
 .../inventorymgmt/common/constants/TrustFlag.java  |  13 +
 .../common/exception/ErrorDictionary.java          |   5 +-
 .../configuration/ConfigurationService.java        |  37 +-
 .../com/mvwc/inventorymgmt/configuration/Days.java |   5 +-
 .../inventorymgmt/epeat/grid/EpeatGridService.java |  14 +-
 .../inventorymgmt/file/upload/ElectionRequest.java |   8 +-
 .../file/upload/FileActivityService.java           |   4 +-
 .../inventorymgmt/file/upload/FileService.java     |   6 +-
 .../file/upload/FileUploadService.java             |  49 +-
 .../file/upload/ProactiveDepositService.java       |   2 +-
 .../com/mvwc/inventorymgmt/ibmMQ/Consumer.java     |  36 --
 .../com/mvwc/inventorymgmt/ibmMQ/JMSFactory.java   |  86 ++--
 .../com/mvwc/inventorymgmt/ibmMQ/Producer.java     |  42 --
 .../inquiry/EPeatRecordInquiryRequest.java         |  10 +-
 .../inquiry/EPeatRecordInquiryService.java         |  22 +-
 .../mvwc/inventorymgmt/inquiry/EPeatRecords.java   |  14 +-
 .../inquiry/ProjectPhaseFileProgress.java          |   2 -
 .../inquiry/WeeksInquiryController.java            |  14 +-
 .../inventorymgmt/inquiry/WeeksInquiryService.java |  50 ++-
 .../marshaconfig/MarshaConfigService.java          | 106 ++++-
 .../inventorymgmt/marshaconfig/PointsBlockDto.java |  18 +
 .../marshaconfig/ResConfigRequest.java             |   7 +-
 .../marshaconfig/ResConfigSearchResponse.java      |   2 +
 .../mvwc/inventorymgmt/report/ReportService.java   |   8 +-
 .../schedular/AutoGenerateService.java             | 339 +++++---------
 .../schedular/AutoGenerateTransaction.java         |   2 +-
 .../inventorymgmt/schedular/CronScheduler.java     |   1 +
 .../inventorymgmt/schedular/EPeatExtractDto.java   |  12 +-
 .../schedular/MarshaBookingRetryService.java       | 151 ++++---
 .../mvwc/inventorymgmt/schedular/Scheduler.java    |   2 +
 .../schedular/SchedulerController.java             |   1 +
 .../inventorymgmt/schedular/SchedulerService.java  |  29 +-
 .../transactions/AlgorithmConsumer.java            |  83 ++++
 .../transactions/EpeatTransactionsResponse.java    |   4 +-
 .../transactions/MessageQueueRequest.java          |  26 ++
 .../inventorymgmt/transactions/ProductFormReq.java |  18 +
 .../transactions/TransactionController.java        |   6 +-
 .../transactions/TransactionService.java           | 241 +++++++---
 .../transactions/TriggerAlgorithmRequest.java      |   4 +-
 .../inventorymgmt/uv/sys/init/PeatDepositData.java |   2 +
 .../uv/sys/init/PeatDepositService.java            |   4 +-
 .../uv/sys/init/PeatMarshaService.java             |   2 +-
 .../uv/sys/init/PeatTransactionData.java           |   4 +
 .../uv/sys/init/PeatTransactionQueueData.java      |   4 +
 .../uv/sys/init/PeatTransactionQueueService.java   |  13 +-
 .../uv/sys/init/PeatTransactionService.java        |  11 +-
 .../uv/sys/init/UVTransactionFileService.java      |  23 +-
 src/main/resources/application.properties          |  21 +-
 .../ConfigurationControllerIntTest.java            |   6 +-
 .../transactions/TransactionControllerIntTest.java |  66 +++
 .../inventorymgmt/algorithm/AutoSubDtoTest.java    |   6 +-
 .../algorithm/MatchingRuleServiceTest.java         |  39 +-
 .../algorithm/MicroSeasonSelectionDtoTest.java     |  83 ++++
 .../algorithm/PointsAlgoServiceTest.java           |   9 -
 .../algorithm/TotalExchangeBlockDtoTest.java       |  58 +++
 .../algorithm/WeeksAlgoServiceTest.java            | 305 +++++++------
 .../database/file/progress/ProductFormTest.java    |   6 +
 .../database/file/progress/SourceElectionTest.java |  15 +-
 .../inventory/type/EPeatRecordDaoImplTest.java     | 492 +++++++++++++++++++++
 .../database/inventory/type/EmailGroupTest.java    |  51 +++
 .../database/inventory/type/PEATRequestTest.java   |   6 +-
 .../type/PeatActionSpecificationTest.java          |  78 ++++
 .../inventory/type/SearchCriteriaTest.java         |  46 ++
 .../client/database/inventory/type/TrustTest.java  |   9 +-
 .../client/database/phase/PropertyTest.java        |  70 +++
 .../client/database/project/ProjectPhaseTest.java  | 137 ++++++
 .../client/database/project/ProjectTrustTest.java  |  43 ++
 .../client/database/res/config/ResConfigTest.java  |   8 +-
 .../configuration/ConfigurationServiceTest.java    |  36 +-
 .../mvwc/inventorymgmt/configuration/DaysTest.java |   8 +-
 .../epeat/grid/EpeatGridServiceTest.java           | 110 ++++-
 .../epeat/grid/PointPackageSummaryTest.java        |  44 ++
 .../epeat/grid/PointsGridDtoTest.java              |  60 +++
 .../epeat/grid/PointsGridResponseTest.java         |  51 +++
 .../epeat/grid/RoomPoolGridDtoTest.java            |  42 ++
 .../inventorymgmt/epeat/grid/WeeksGridDtoTest.java |  82 ++++
 .../file/upload/CalendarValuationServiceTest.java  |  56 ++-
 .../file/upload/ElectionRequestTest.java           |  12 +-
 .../inventorymgmt/file/upload/FileServiceTest.java | 187 ++++++++
 .../file/upload/FileUploadServiceTest.java         |  99 +++--
 .../file/upload/TrustServiceTest.java              |  58 ++-
 .../inquiry/EPeatRecordInquiryControllerTest.java  |  74 ++++
 .../inquiry/EPeatRecordInquiryRequestTest.java     |  92 ++++
 .../inquiry/EPeatRecordInquiryResponseTest.java    |  53 +++
 .../inquiry/EPeatRecordInquiryServiceTest.java     | 305 ++++++++++++-
 .../inventorymgmt/inquiry/EPeatRecordsTest.java    | 138 ++++++
 .../com/mvwc/inventorymgmt/inquiry/FilterTest.java |  46 ++
 .../mvwc/inventorymgmt/inquiry/PaginationTest.java |  39 ++
 .../inquiry/PeatActionResponseTest.java            |  61 +++
 .../inquiry/ProjectPhaseFileProgressTest.java      |  83 ++++
 .../inquiry/SeasonInquiryseasonTest.java           |  67 +++
 .../mvwc/inventorymgmt/inquiry/SortingTest.java    |  40 ++
 .../mvwc/inventorymgmt/inquiry/ValuationsTest.java |  48 ++
 .../inquiry/WeeksInquiryServiceTest.java           | 137 +++++-
 .../booking/api/client/stub/AddressTest.java       |  42 ++
 .../api/client/stub/ApplicationErrorTypeTest.java  |  37 ++
 .../api/client/stub/ApplicationFaultTypeTest.java  |  34 ++
 .../marsha/booking/api/client/stub/CancelTest.java |  34 ++
 .../api/client/stub/LookupResponseTest.java        |  46 ++
 .../api/client/stub/MVCIMessageMetaDataTest.java   |  50 +++
 .../api/client/stub/MVCIMessageMetaFieldTest.java  |  32 ++
 .../MessageBodyValidationFailureFaultTypeTest.java |  51 +++
 .../api/client/stub/ParseMessageTypeTest.java      |  41 ++
 .../api/client/stub/PingInputMessageTypeTest.java  |  37 ++
 .../client/stub/PingOutputMessageListTypeTest.java |  32 ++
 .../api/client/stub/PingOutputMessageTypeTest.java |  44 ++
 .../api/client/stub/PingResponseTypeTest.java      |  36 ++
 .../booking/api/client/stub/PingTypeTest.java      |  32 ++
 .../booking/api/client/stub/PreferenceTest.java    |  39 ++
 .../api/client/stub/ReleaseResponseTest.java       |  33 ++
 .../booking/api/client/stub/ReleaseTest.java       |  30 ++
 .../booking/api/client/stub/ReservationTest.java   |  68 +++
 .../api/client/stub/SearchManyResponseTest.java    |  39 ++
 .../booking/api/client/stub/SearchManyTest.java    |  34 ++
 .../api/client/stub/SearchResponseTest.java        |  40 ++
 .../marsha/booking/api/client/stub/SearchTest.java |  55 +++
 .../booking/api/client/stub/SegmentListTest.java   |  37 ++
 .../booking/api/client/stub/SegmentTest.java       |  58 +++
 .../stub/ServiceUnavailableFaultTypeTest.java      |  35 ++
 .../api/client/stub/StaleDataErrorTypeTest.java    |  40 ++
 .../api/client/stub/StaleDataFaultTypeTest.java    |  34 ++
 .../api/client/stub/StatusInformationTest.java     |  35 ++
 .../marsha/booking/api/client/stub/StatusTest.java |  41 ++
 .../marsha/booking/api/client/stub/StayTest.java   |  53 +++
 .../api/client/stub/ValidationErrorTypeTest.java   |  33 ++
 .../api/configuration/MarshaBookingHelperTest.java | 114 +++++
 .../marshaconfig/MarshaConfigServiceTest.java      | 147 +++++-
 .../marshaconfig/ResConfigRequestTest.java         |  13 +-
 .../marshaconfig/ResConfigSearchResponseTest.java  |  12 +-
 .../inventorymgmt/report/ReportServiceTest.java    |   6 +-
 .../schedular/AutoGenerateServiceTest.java         | 153 ++++++-
 .../schedular/AutoGenerateTransactionTest.java     |   8 +-
 .../schedular/EPeatExtractDTOTest.java             | 104 +++++
 .../schedular/MarshaBookingRetryServiceTest.java   |  62 ++-
 .../schedular/SchedulerServiceTest.java            |  42 +-
 .../inventorymgmt/schedular/SchedulerTest.java     |  40 +-
 .../transactions/AlgoProcessDtoTest.java           |  39 ++
 .../EpeatTransactionsResponseTest.java             |  11 +-
 .../transactions/MessageQueueRequestTest.java      |  60 +++
 .../transactions/ProductFormReqTest.java           |  38 ++
 .../transactions/TransactionServiceTest.java       | 222 +++++++++-
 .../transactions/TriggerAlgorithmRequestTest.java  |  10 +-
 .../uv/sys/init/PeatDepositDataTest.java           |   5 +-
 .../uv/sys/init/PeatTransactionDataTest.java       |   8 +-
 .../uv/sys/init/PeatTransactionQueueDataTest.java  |   8 +-
 src/test/resources/data.sql                        |   6 +-
 164 files changed, 6996 insertions(+), 1292 deletions(-)
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/algorithm/MarshaBookingParamsDto.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/algorithm/ProjectThresholds.java
 rename src/main/java/com/mvwc/inventorymgmt/{schedular => client/database/inventory/type}/EmailGroup.java (85%)
 rename src/main/java/com/mvwc/inventorymgmt/{schedular => client/database/inventory/type}/EmailGroupRepository.java (79%)
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/common/constants/TrustFlag.java
 delete mode 100644 src/main/java/com/mvwc/inventorymgmt/ibmMQ/Consumer.java
 delete mode 100644 src/main/java/com/mvwc/inventorymgmt/ibmMQ/Producer.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/marshaconfig/PointsBlockDto.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/transactions/AlgorithmConsumer.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/transactions/MessageQueueRequest.java
 create mode 100644 src/main/java/com/mvwc/inventorymgmt/transactions/ProductFormReq.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/algorithm/MicroSeasonSelectionDtoTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/algorithm/TotalExchangeBlockDtoTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/EPeatRecordDaoImplTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/EmailGroupTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/PeatActionSpecificationTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/SearchCriteriaTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/phase/PropertyTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/project/ProjectPhaseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/client/database/project/ProjectTrustTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/PointPackageSummaryTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/PointsGridDtoTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/PointsGridResponseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/RoomPoolGridDtoTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/WeeksGridDtoTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryRequestTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryResponseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordsTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/FilterTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/PaginationTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/PeatActionResponseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/ProjectPhaseFileProgressTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/SeasonInquiryseasonTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/SortingTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/inquiry/ValuationsTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/AddressTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ApplicationErrorTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ApplicationFaultTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/CancelTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/LookupResponseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/MVCIMessageMetaDataTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/MVCIMessageMetaFieldTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/MessageBodyValidationFailureFaultTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ParseMessageTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingInputMessageTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingOutputMessageListTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingOutputMessageTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingResponseTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingTypeTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PreferenceTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ReleaseResponseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ReleaseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ReservationTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchManyResponseTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchManyTest.java
 create mode 100644 src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchResponseTest.java
Updating files: 100% (177/177), done.
Switched to branch 'feature/gkulk'
M       target/classes/application.properties
M       target/test-classes/application.properties
Your branch and 'origin/integration' have diverged,
and have 1 and 178 different commits each, respectively.
  (use "git pull" to merge the remote branch into yours)

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git merge integration
Auto-merging src/main/java/com/mvwc/inventorymgmt/common/constants/Constants.java
CONFLICT (content): Merge conflict in src/main/java/com/mvwc/inventorymgmt/common/constants/Constants.java
Auto-merging src/main/java/com/mvwc/inventorymgmt/common/exception/ErrorDictionary.java
CONFLICT (content): Merge conflict in src/main/java/com/mvwc/inventorymgmt/common/exception/ErrorDictionary.java
Automatic merge failed; fix conflicts and then commit the result.

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk|MERGING)
$ git sta
stage    stash    status

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk|MERGING)
$ git status
On branch feature/gkulk
Your branch and 'origin/integration' have diverged,     
and have 1 and 178 different commits each, respectively.
  (use "git pull" to merge the remote branch into yours)

You have unmerged paths.
  (fix conflicts and run "git commit")
  (use "git merge --abort" to abort the merge)

Changes to be committed:
        modified:   pom.xml
        modified:   src/main/java/com/mvwc/inventorymgmt/algorithm/AutoSubDto.java
        new file:   src/main/java/com/mvwc/inventorymgmt/algorithm/MarshaBookingParamsDto.java
        modified:   src/main/java/com/mvwc/inventorymgmt/algorithm/MatchingRuleService.java   
        modified:   src/main/java/com/mvwc/inventorymgmt/algorithm/PointsAlgoServiceImpl.java
        new file:   src/main/java/com/mvwc/inventorymgmt/algorithm/ProjectThresholds.java
        modified:   src/main/java/com/mvwc/inventorymgmt/algorithm/WeeksAlgoServiceImpl.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/file/progress/SourceElection.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/file/progress/SourceElectiontRepository.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/EPeatRecordDaoImpl.java
        renamed:    src/main/java/com/mvwc/inventorymgmt/schedular/EmailGroup.java -> src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/EmailGroup.ja
va
        renamed:    src/main/java/com/mvwc/inventorymgmt/schedular/EmailGroupRepository.java -> src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/Ema
ilGroupRepository.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/PEATAction.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/PEATActionRepository.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/PEATActionSpecification.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/inventory/type/PEATRequest.java
        modified:   src/main/java/com/mvwc/inventorymgmt/client/database/res/config/ResConfig.java
        new file:   src/main/java/com/mvwc/inventorymgmt/common/constants/TrustFlag.java
        modified:   src/main/java/com/mvwc/inventorymgmt/configuration/ConfigurationService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/configuration/Days.java
        modified:   src/main/java/com/mvwc/inventorymgmt/epeat/grid/EpeatGridService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/file/upload/ElectionRequest.java
        modified:   src/main/java/com/mvwc/inventorymgmt/file/upload/FileActivityService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/file/upload/FileService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/file/upload/FileUploadService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/file/upload/ProactiveDepositService.java
        deleted:    src/main/java/com/mvwc/inventorymgmt/ibmMQ/Consumer.java
        modified:   src/main/java/com/mvwc/inventorymgmt/ibmMQ/JMSFactory.java
        deleted:    src/main/java/com/mvwc/inventorymgmt/ibmMQ/Producer.java
        modified:   src/main/java/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryRequest.java
        modified:   src/main/java/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/inquiry/EPeatRecords.java
        modified:   src/main/java/com/mvwc/inventorymgmt/inquiry/ProjectPhaseFileProgress.java
        modified:   src/main/java/com/mvwc/inventorymgmt/inquiry/WeeksInquiryController.java
        modified:   src/main/java/com/mvwc/inventorymgmt/inquiry/WeeksInquiryService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/marshaconfig/MarshaConfigService.java
        new file:   src/main/java/com/mvwc/inventorymgmt/marshaconfig/PointsBlockDto.java
        modified:   src/main/java/com/mvwc/inventorymgmt/marshaconfig/ResConfigRequest.java
        modified:   src/main/java/com/mvwc/inventorymgmt/marshaconfig/ResConfigSearchResponse.java
        modified:   src/main/java/com/mvwc/inventorymgmt/report/ReportService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/AutoGenerateService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/AutoGenerateTransaction.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/CronScheduler.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/EPeatExtractDto.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/MarshaBookingRetryService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/Scheduler.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/SchedulerController.java
        modified:   src/main/java/com/mvwc/inventorymgmt/schedular/SchedulerService.java
        new file:   src/main/java/com/mvwc/inventorymgmt/transactions/AlgorithmConsumer.java
        modified:   src/main/java/com/mvwc/inventorymgmt/transactions/EpeatTransactionsResponse.java
        new file:   src/main/java/com/mvwc/inventorymgmt/transactions/MessageQueueRequest.java
        new file:   src/main/java/com/mvwc/inventorymgmt/transactions/ProductFormReq.java
        modified:   src/main/java/com/mvwc/inventorymgmt/transactions/TransactionController.java
        modified:   src/main/java/com/mvwc/inventorymgmt/transactions/TransactionService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/transactions/TriggerAlgorithmRequest.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatDepositData.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatDepositService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatMarshaService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatTransactionData.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatTransactionQueueData.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatTransactionQueueService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/PeatTransactionService.java
        modified:   src/main/java/com/mvwc/inventorymgmt/uv/sys/init/UVTransactionFileService.java
        modified:   src/main/resources/application.properties
        modified:   src/test/java/integration/com/mvwc/inventorymgmt/configuration/ConfigurationControllerIntTest.java
        modified:   src/test/java/integration/com/mvwc/inventorymgmt/transactions/TransactionControllerIntTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/algorithm/AutoSubDtoTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/algorithm/MatchingRuleServiceTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/algorithm/MicroSeasonSelectionDtoTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/algorithm/PointsAlgoServiceTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/algorithm/TotalExchangeBlockDtoTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/algorithm/WeeksAlgoServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/client/database/file/progress/ProductFormTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/client/database/file/progress/SourceElectionTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/EPeatRecordDaoImplTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/EmailGroupTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/PEATRequestTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/PeatActionSpecificationTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/SearchCriteriaTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/client/database/inventory/type/TrustTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/phase/PropertyTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/project/ProjectPhaseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/client/database/project/ProjectTrustTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/client/database/res/config/ResConfigTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/configuration/ConfigurationServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/configuration/DaysTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/EpeatGridServiceTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/PointPackageSummaryTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/PointsGridDtoTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/PointsGridResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/RoomPoolGridDtoTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/epeat/grid/WeeksGridDtoTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/file/upload/CalendarValuationServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/file/upload/ElectionRequestTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/file/upload/FileServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/file/upload/FileUploadServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/file/upload/TrustServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryControllerTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryRequestTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryResponseTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordInquiryServiceTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/EPeatRecordsTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/FilterTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/PaginationTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/PeatActionResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/ProjectPhaseFileProgressTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/SeasonInquiryseasonTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/SortingTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/ValuationsTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/inquiry/WeeksInquiryServiceTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/AddressTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ApplicationErrorTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ApplicationFaultTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/CancelTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/LookupResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/MVCIMessageMetaDataTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/MVCIMessageMetaFieldTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/MessageBodyValidationFailureFaultTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ParseMessageTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingInputMessageTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingOutputMessageListTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingOutputMessageTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingResponseTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PingTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/PreferenceTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ReleaseResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ReleaseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ReservationTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchManyResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchManyTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SearchTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SegmentListTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/SegmentTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ServiceUnavailableFaultTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/StaleDataErrorTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/StaleDataFaultTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/StatusInformationTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/StatusTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/StayTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/client/stub/ValidationErrorTypeTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/marsha/booking/api/configuration/MarshaBookingHelperTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/marshaconfig/MarshaConfigServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/marshaconfig/ResConfigRequestTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/marshaconfig/ResConfigSearchResponseTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/report/ReportServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/schedular/AutoGenerateServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/schedular/AutoGenerateTransactionTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/schedular/EPeatExtractDTOTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/schedular/MarshaBookingRetryServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/schedular/SchedulerServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/schedular/SchedulerTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/transactions/AlgoProcessDtoTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/transactions/EpeatTransactionsResponseTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/transactions/MessageQueueRequestTest.java
        new file:   src/test/java/test/com/mvwc/inventorymgmt/transactions/ProductFormReqTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/transactions/TransactionServiceTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/transactions/TriggerAlgorithmRequestTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/uv/sys/init/PeatDepositDataTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/uv/sys/init/PeatTransactionDataTest.java
        modified:   src/test/java/test/com/mvwc/inventorymgmt/uv/sys/init/PeatTransactionQueueDataTest.java
        modified:   src/test/resources/data.sql

Unmerged paths:
  (use "git add <file>..." to mark resolution)
        both modified:   src/main/java/com/mvwc/inventorymgmt/common/constants/Constants.java
        both modified:   src/main/java/com/mvwc/inventorymgmt/common/exception/ErrorDictionary.java

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
        modified:   target/classes/application.properties
        modified:   target/test-classes/application.properties

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        .classpath
        .factorypath
        .settings/
        nullnullfilename.csv
        target/classes/CASSECURE.TAB
        target/classes/ESAPI.properties
        target/classes/META-INF/
        target/classes/data/
        target/classes/truststore.jks
        target/classes/validation.properties
        target/maven-status/
        target/surefire-reports/
        target/test-classes/data.sql
        target/test-classes/file-upload.csv
        target/test-classes/integration/
        target/test-classes/load_trust_inventory_details.csv
        target/test-classes/test/


gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk|MERGING)
$ git add  src/main/java/com/mvwc/inventorymgmt/common/constants/Constants.java src/main/java/com/mvwc/inventorymgmt/common/exception/ErrorDictionary.java

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk|MERGING)
$ git commit -m "conflicts resolved"
[feature/gkulk a19939de] conflicts resolved
 Committer: Kulkarni <Girish.Kulkarni@vacationclub.com>
Your name and email address were configured automatically based
on your username and hostname. Please check that they are accurate.
You can suppress this message by setting them explicitly:

    git config --global user.name "Your Name"
    git config --global user.email you@example.com

After doing this, you may fix the identity used for this commit with:

    git commit --amend --reset-author


gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git checkout integration
Switched to branch 'integration'
M       target/classes/application.properties
M       target/test-classes/application.properties
Your branch is up to date with 'origin/integration'.

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git pull
Already up to date.

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (integration)
$ git checkout feature/gkulk
Switched to branch 'feature/gkulk'

    git push origin HEAD

To choose either option permanently, see push.default in 'git help config'.

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$ git push origin feature/gkulk
Enumerating objects: 91, done.
Counting objects: 100% (88/88), done.
Delta compression using up to 4 threads
Compressing objects: 100% (37/37), done.
Writing objects: 100% (51/51), 17.09 KiB | 795.00 KiB/s, done.
Total 51 (delta 20), reused 0 (delta 0), pack-reused 0
To https://bitbucket.iilg.com/scm/mvwcas/mvw-cas-inventory-movement-engine-sapi-v1.git
 * [new branch]        feature/gkulk -> feature/gkulk

gkulk730@DCMCO3DVD1426 MINGW64 ~/git/mvw-cas-inventory-movement-engine-sapi-v1 (feature/gkulk)
$